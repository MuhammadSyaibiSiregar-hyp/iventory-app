exports.dashboard = async (req, res) => {
  const items = await Item.findAll({ where: { is_active: true }});
  res.render("dashboard", {
    items: items,
    user: req.user
  });
};

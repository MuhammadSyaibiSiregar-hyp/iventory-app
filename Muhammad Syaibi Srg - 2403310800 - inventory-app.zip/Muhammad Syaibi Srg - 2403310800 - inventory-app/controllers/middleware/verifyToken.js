module.exports = (req, res, next) => {
  req.user = { username: "admin", role: "manager" };
  next();
};

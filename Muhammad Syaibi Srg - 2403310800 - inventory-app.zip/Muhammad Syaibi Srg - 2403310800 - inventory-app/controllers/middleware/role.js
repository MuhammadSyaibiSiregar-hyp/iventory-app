exports.managerOnly = (req, res, next) => {
  if (req.user.role !== "manager") return res.send("Akses ditolak");
  next();
};

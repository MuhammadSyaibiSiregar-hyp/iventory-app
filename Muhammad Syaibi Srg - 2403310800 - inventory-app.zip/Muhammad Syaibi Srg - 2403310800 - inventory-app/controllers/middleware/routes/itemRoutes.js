const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/itemController");
const verify = require("../middleware/verifyToken");
const { managerOnly } = require("../middleware/role");

router.get("/dashboard", verify, ctrl.dashboard);
router.post("/items", verify, managerOnly, ctrl.create);
router.post("/items/:id", verify, ctrl.update);
router.post("/items/delete/:id", verify, managerOnly, ctrl.delete);

module.exports = router;
